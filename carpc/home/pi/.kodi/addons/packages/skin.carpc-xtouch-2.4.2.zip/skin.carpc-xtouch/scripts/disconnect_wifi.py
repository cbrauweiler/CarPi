import os

os.system("sudo /sbin/ifdown wlan0");
